"""importing a unittest case"""
import unittest
import feature


class TestCubeRoot(unittest.TestCase):
    """test case"""

    def test_cube_root(self):
        """test case for check cube root"""
        self.assertEqual(feature.cube_root(8), 2)

    def test_cube_root_negative(self):
        """test case for check cube root"""
        self.assertEqual(feature.cube_root(-8), -2)

    def test_cube_root1(self):
        """test case for exception"""
        self.assertRaises(TypeError, feature.cube_root("hi"), "enter only numbers")

if __name__ == '__main__':
    unittest.main()





