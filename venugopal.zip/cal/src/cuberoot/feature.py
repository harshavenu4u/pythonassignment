"""program"""
import logging
logging.basicConfig(filename="configfile.log", level=logging.ERROR, format='%(asctime)s:%(levelname)s:%(message)s',
                        filemode='w')

def cube_root(n_value):
    """function"""
    try:

        v = int(n_value)
        if v > 0:
            print(v**(1/3))
            return v**(1/3)

        elif v < 0:
            print(-(-v)**(1/3))
            return -(-v)**(1/3)

    except ValueError :
        logging.error(ValueError)
        return "ValueError"
